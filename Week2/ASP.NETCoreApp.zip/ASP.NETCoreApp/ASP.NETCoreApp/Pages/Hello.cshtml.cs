using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP.NETCoreApp.Pages
{
    public class HelloModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
