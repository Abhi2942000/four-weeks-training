using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProductController.Pages
{
    public class ProductControllerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
